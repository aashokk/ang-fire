// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

// NOTE: MAKE SURE TO PASTE IN YOUR OWN PROJECT SPECIFIC CONFIGURATION FOR FIREBASE BELOW.
// USING THE SAME CONFIGURATION WON'T WORK

export const environment = {
  production: false,
  firebase: {
    apiKey: 'AIzaSyCfJaUeHH9dlCSV_Sy2B1ymHOIhI8XymMA',
    authDomain: 'fire-authn.firebaseapp.com',
    databaseURL: 'https://fire-authn.firebaseio.com',
    projectId: 'fire-authn',
    storageBucket: 'fire-authn.appspot.com',
    messagingSenderId: '484684887987'
  },
  modes: {
    POPUP: 'popup',
    REDIRECT: 'redirect'
  },
  providers: {
    GOOGLE: 'google',
    FACEBOOK: 'facebook',
    TWITTER: 'twitter',
    GITHUB: 'github'
  }
};
