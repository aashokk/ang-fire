import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

import { AppFirebaseModule } from './app-firebase/app-firebase.module';

import { AppComponent } from './app.component';

import { AuthService } from './common/auth/auth.service';
import { WindowService } from './common/window/window.service';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppFirebaseModule
  ],
  providers: [
    AuthService,
    WindowService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
