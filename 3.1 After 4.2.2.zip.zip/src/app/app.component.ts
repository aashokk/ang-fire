import { Component, OnInit, AfterViewInit } from '@angular/core';

import { AngularFireAuth } from 'angularfire2/auth';
import * as firebase from 'firebase';

import { AuthService } from './common/auth/auth.service';
import { WindowService } from './common/window/window.service';
import { environment } from '../environments/environment';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, AfterViewInit {

  email: string;
  password: string;
  signInMode = false;
  phoneNumber: string;
  otp: string;
  phoneSignIn = true;
  windowRef: any;
  disableOTPSendButton = true;
  providers = environment.providers;
  modes = environment.modes;

  constructor(
    public afAuth: AngularFireAuth,
    private authService: AuthService,
    private windowService: WindowService
  ) { }

  ngOnInit() {
    this.windowRef = this.windowService.windowRef;
  }

  ngAfterViewInit() {
    this.windowRef.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('recaptcha-container', {
      'size': 'normal',
      'callback': (response) => {
        this.disableOTPSendButton = false;
      }
    });
    this.windowRef.recaptchaVerifier.render();
  }

  sendOTP() {
    this.afAuth.auth.signInWithPhoneNumber(this.phoneNumber, this.windowRef.recaptchaVerifier).then((confirmationResult) => {
      this.windowRef.confirmationResult = confirmationResult;
    });
  }

  verifyOTP() {
    this.windowRef.confirmationResult.confirm(this.otp)
      .then((userCredentials) => console.log(userCredentials));
  }

  signInWithModeAndProvider(mode: string, provider: string) {
    this.authService.signIn(mode, provider);
  }

  signInAnonymously() {
    this.authService.signInAnonymously();
  }

  signInOrSignUp() {
    this.authService.signInOrSignUp(this.email, this.password, this.signInMode);
  }

  toggleSignInMode() {
    this.signInMode = !this.signInMode;
  }

  togglePhoneSignIn() {
    this.phoneSignIn = !this.phoneSignIn;
  }

  logout() {
    this.authService.logout();
  }
}
